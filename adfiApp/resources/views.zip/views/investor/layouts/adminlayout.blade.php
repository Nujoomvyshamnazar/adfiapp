@include('investor.includes.head')

    @include('investor.includes.header')

        @include('investor.includes.leftmenu')




            @include('investor.includes.footer')
