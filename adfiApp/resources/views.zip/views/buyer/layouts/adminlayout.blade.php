@include('buyer.includes.head')

    @include('buyer.includes.header')

        @include('buyer.includes.leftmenu')




            @include('buyer.includes.footer')
