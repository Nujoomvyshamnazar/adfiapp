<a id="back-to-top" href="#" class="btn btn-primary btn-lg back-to-top" role="button" title="Return to top" data-toggle="tooltip" data-placement="left">
       <i class="livicon" data-name="plane-up" data-size="18" data-loop="true" data-c="#fff" data-hc="white"></i>
   </a>
   <!-- global js -->
   <script src="{{asset('assets/js/app.js')}}" type="text/javascript"></script>
   <!-- end of global js -->
   <!-- begining of page level js -->
   <!-- EASY PIE CHART JS -->
   <script src="{{asset('assets/vendors/jquery.easy-pie-chart/js/easypiechart.min.js')}}"></script>
   <script src="{{asset('assets/vendors/jquery.easy-pie-chart/js/jquery.easypiechart.min.js')}}"></script>
   <script src="{{asset('assets/js/jquery.easingpie.js')}}"></script>
   <!--end easy pie chart -->
   <!--for calendar-->
   <script src="{{asset('assets/vendors/moment/js/moment.min.js')}}" type="text/javascript"></script>
   <script src="{{asset('assets/vendors/fullcalendar/js/fullcalendar.min.js')}}" type="text/javascript"></script>
   <!--   Realtime Server Load  -->
   <script src="{{asset('assets/vendors/flotchart/js/jquery.flot.js')}}" type="text/javascript"></script>
   <script src="{{asset('assets/vendors/flotchart/js/jquery.flot.resize.js')}}" type="text/javascript"></script>
   <!--Sparkline Chart-->
   <script src="{{asset('assets/vendors/sparklinecharts/jquery.sparkline.js')}}"></script>
   <!-- Back to Top-->
   <script type="{{asset('assets/text/javascript" src="vendors/countUp.js/js/countUp.js')}}"></script>
   <!--   maps -->
   <script src="{{asset('assets/vendors/bower-jvectormap/js/jquery-jvectormap-1.2.2.min.js')}}"></script>
   <script src="{{asset('assets/vendors/bower-jvectormap/js/jquery-jvectormap-world-mill-en.js')}}"></script>
   <script src="{{asset('assets/vendors/chartjs/Chart.js')}}"></script>
   <script type="text/javascript" src="{{asset('assets/vendors/datetimepicker/js/bootstrap-datetimepicker.min.js')}}"></script>
   <!--  todolist-->
   <script src="{{asset('assets/js/pages/todolist.js')}}"></script>

<!-- end of global js -->
<script type="text/javascript" src="{{asset('assets/vendors/datatables/js/jquery.dataTables.js')}}"></script>
<script type="text/javascript" src="{{asset('assets/vendors/datatables/js/dataTables.bootstrap.js')}}"></script>
<script type="text/javascript" src="{{asset('assets/vendors/datatables/js/dataTables.responsive.js')}}"></script>
<script src="{{asset('assets/js/pages/table-responsive.js')}}"></script>

@yield('addfooter')

</html>
