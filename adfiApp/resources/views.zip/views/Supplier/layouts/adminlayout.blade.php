@include('supplier.includes.head')

    @include('supplier.includes.header')

        @include('supplier.includes.leftmenu')




            @include('supplier.includes.footer')
